import { Vehicle } from './types';

export const VEHICLES: Vehicle[] = [
  {
    id: '1',
    brand: 'Toyota',
    model: 'Hilux SRX 4x4',
    year: 2022,
    price: 45000,
    type: 'Pickup',
    km: 35000,
    fuel: 'Diesel',
    transmission: 'Automática',
    images: [
      'https://picsum.photos/seed/hilux1/800/600',
      'https://picsum.photos/seed/hilux2/800/600',
      'https://picsum.photos/seed/hilux3/800/600'
    ],
    description: 'Excelente estado, único dueño. Todos los servicios oficiales realizados en Toyota.',
    featured: true
  },
  {
    id: '2',
    brand: 'Volkswagen',
    model: 'Vento GLI',
    year: 2021,
    price: 32000,
    type: 'Sedan',
    km: 28000,
    fuel: 'Nafta',
    transmission: 'Automática DSG',
    images: [
      'https://picsum.photos/seed/vento1/800/600',
      'https://picsum.photos/seed/vento2/800/600'
    ],
    description: 'Impecable estado, service al día. Cubiertas nuevas.',
    featured: true
  },
  {
    id: '3',
    brand: 'Jeep',
    model: 'Compass Limited',
    year: 2023,
    price: 38500,
    type: 'SUV',
    km: 12000,
    fuel: 'Nafta',
    transmission: 'Automática',
    images: [
      'https://picsum.photos/seed/compass1/800/600',
      'https://picsum.photos/seed/compass2/800/600'
    ],
    description: 'Prácticamente nueva. Garantía de fábrica vigente.',
    featured: true
  },
  {
    id: '4',
    brand: 'Peugeot',
    model: '208 Feline',
    year: 2022,
    price: 19500,
    type: 'Hatchback',
    km: 22000,
    fuel: 'Nafta',
    transmission: 'Automática',
    images: [
      'https://picsum.photos/seed/208-1/800/600',
      'https://picsum.photos/seed/208-2/800/600'
    ],
    description: 'Full equipo, techo panorámico, cámara 360.'
  },
  {
    id: '5',
    brand: 'Ford',
    model: 'Ranger Limited',
    year: 2020,
    price: 35000,
    type: 'Pickup',
    km: 55000,
    fuel: 'Diesel',
    transmission: 'Automática',
    images: [
      'https://picsum.photos/seed/ranger1/800/600'
    ],
    description: 'Lista para trabajar o viajar. Muy cuidada.'
  },
  {
    id: '6',
    brand: 'Chevrolet',
    model: 'Cruze Premier',
    year: 2021,
    price: 24000,
    type: 'Sedan',
    km: 31000,
    fuel: 'Nafta',
    transmission: 'Automática',
    images: [
      'https://picsum.photos/seed/cruze1/800/600'
    ],
    description: 'Tecnología OnStar, WiFi nativo, excelente consumo.'
  }
];
